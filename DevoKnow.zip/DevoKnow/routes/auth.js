const express = require('express');
const mysql = require("mysql2");
const router = express.Router();

// Rota de login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Consulta o usuário no banco de dados
  db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
    if (err) {
      return res.status(500).send('Erro ao acessar o banco de dados.');
    }

    if (results.length > 0) {
      const user = results[0];
      // Verifica a senha
      bcrypt.compare(password, user.password, (err, match) => {
        if (err) {
          return res.status(500).send('Erro ao verificar a senha.');
        }

        if (match) {
          // Autenticação bem-sucedida
          req.session.userId = user.id; 
          return res.redirect('/quiz');
        } else {
          return res.send('Senha incorreta!');
        }
      });
    } else {
      return res.send('Usuário não encontrado!');
    }
  });
});

function checkAuth(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  } else {
    res.redirect('/login');
  }
}

module.exports = { router, checkAuth };
