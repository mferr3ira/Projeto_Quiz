const mysql = require("mysql2/promise");

const db = mysql.createPool({
    host: "localhost",
    user: "matheus",
    password: "matheus",
    database: "devo_know",
});

module.exports = db;