const express = require("express");
const path = require("path");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const session = require("express-session");
const { checkAuth } = require("./routes/auth");
const app = express();
const port = 3000;

// Configuração do banco de dados
const db = mysql.createConnection({
  host: "localhost",
  user: "matheus",
  password: "matheus",
  database: "devo_know"
});

db.connect((err) => {
  if (err) throw err;
  console.log("Conectado ao banco de dados MySQL");
});

// Middleware para servir arquivos estáticos
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'segredo',
  resave: false,
  saveUninitialized: true
}));

// Rota para a página de bem-vindo (index.html)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"));
});

// Rota para a página de login
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "login.html"));
});

app.post("/login", (req, res) => {
  const { login, senha } = req.body;

  db.query('SELECT * FROM users WHERE login = ?', [login], (err, results) => {
    if (err) {
      return res.status(500).send('Erro ao acessar o banco de dados.');
    }
    if (results.length > 0) {
      const user = results[0];
      if (senha === user.senha) {
        req.session.userId = user.id;
        return res.send("Success");
      }
    }
    return res.send('Usuário ou senha incorretos!');
  });
});


// Rota para a página de cadastro
app.get("/cadastro", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "cadastro.html"));
});

// Rota de cadastro
app.post("/cadastro", (req, res) => {
  const { login, senha } = req.body;

  db.query('INSERT INTO users (login, senha) VALUES (?, ?)', [login, senha], (err, result) => {
    if (err) {
      return res.status(500).send('Erro ao registrar o usuário.');
    }
    res.send("Sucesso");
  });
});

// Rota para a página do quiz
app.get("/quiz", checkAuth, (req, res) => {
  if (!req.session.questions) {
    db.query("SELECT * FROM questions ORDER BY RAND() LIMIT 10", (err, results) => {
      if (err) throw err;

      console.log("Perguntas retornadas do banco de dados:", results);

      results.forEach(question => {
        if (question.options) {
          try {
            question.options = JSON.parse(question.options);
          } catch (e) {
            console.error("Erro ao parsear opções JSON para a pergunta:", question.question, e);
          }
        } else {
          console.error("Campo 'options' está vazio ou indefinido para a pergunta:", question.question);
        }
      });

      req.session.questions = results;
      res.sendFile(path.join(__dirname, "views", "quiz.html"));
    });
  } else {
    res.sendFile(path.join(__dirname, "views", "quiz.html"));
  }
});

// Rota para enviar perguntas como JSON
app.get("/quiz/data", checkAuth, (req, res) => {
  res.json(req.session.questions);
});

// Rota para processar e exibir o resultado do quiz
app.post("/quiz/submit", checkAuth, (req, res) => {
  const userAnswers = req.body;
  let pontuacao = 0;

  req.session.questions.forEach((question, index) => {
    if (parseInt(userAnswers[`question${index}`]) == question.correct_option) {
      pontuacao++;
    }
  });

  res.redirect(`/result?pontuacao=${pontuacao}`);
});

////////// Rota para a página de resultado
app.get("/result", checkAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "views", "result.html"));
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
